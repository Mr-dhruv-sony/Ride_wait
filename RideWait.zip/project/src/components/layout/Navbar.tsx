import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Bus, Bell, User } from 'lucide-react';
import { useAuthStore } from '../../stores/authStore';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();
  const { isAuthenticated, user } = useAuthStore();

  const getTitle = () => {
    switch (location.pathname) {
      case '/':
        return 'Home';
      case '/routes':
        return 'Routes';
      case '/report':
        return 'Report Bus';
      case '/profile':
        return 'Profile';
      case '/notifications':
        return 'Notifications';
      default:
        if (location.pathname.startsWith('/routes/')) {
          return 'Route Details';
        }
        return 'RideWait';
    }
  };

  return (
    <nav className="bg-white shadow-sm sticky top-0 z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex-shrink-0 flex items-center">
              <Bus className="h-8 w-8 text-primary-600" />
              <span className="ml-2 text-xl font-bold text-primary-700">RideWait</span>
            </Link>
            <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
              <Link 
                to="/" 
                className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                  location.pathname === '/' 
                    ? 'border-primary-500 text-primary-900' 
                    : 'border-transparent text-neutral-600 hover:text-neutral-800 hover:border-neutral-300'
                }`}
              >
                Home
              </Link>
              <Link 
                to="/routes" 
                className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                  location.pathname === '/routes' || location.pathname.startsWith('/routes/') 
                    ? 'border-primary-500 text-primary-900' 
                    : 'border-transparent text-neutral-600 hover:text-neutral-800 hover:border-neutral-300'
                }`}
              >
                Routes
              </Link>
              <Link 
                to="/report" 
                className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                  location.pathname === '/report' 
                    ? 'border-primary-500 text-primary-900' 
                    : 'border-transparent text-neutral-600 hover:text-neutral-800 hover:border-neutral-300'
                }`}
              >
                Report
              </Link>
            </div>
          </div>
          
          <div className="hidden sm:ml-6 sm:flex sm:items-center sm:space-x-4">
            {isAuthenticated ? (
              <>
                <Link 
                  to="/notifications" 
                  className="p-2 rounded-full text-neutral-600 hover:text-neutral-800 hover:bg-neutral-100"
                >
                  <Bell className="h-6 w-6" />
                </Link>
                <Link 
                  to="/profile" 
                  className="p-1 rounded-full border-2 border-neutral-200 text-neutral-600 hover:text-neutral-800"
                >
                  {user?.photoURL ? (
                    <img src={user.photoURL} alt={user.name} className="h-6 w-6 rounded-full" />
                  ) : (
                    <User className="h-6 w-6" />
                  )}
                </Link>
              </>
            ) : (
              <Link 
                to="/auth" 
                className="px-4 py-2 rounded-md font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
              >
                Login
              </Link>
            )}
          </div>
          
          <div className="flex items-center sm:hidden">
            <h1 className="text-lg font-semibold text-neutral-800">{getTitle()}</h1>
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="ml-4 inline-flex items-center justify-center p-2 rounded-md text-neutral-600 hover:text-neutral-800 hover:bg-neutral-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-primary-500"
            >
              <span className="sr-only">Open main menu</span>
              {isMenuOpen ? (
                <X className="block h-6 w-6" aria-hidden="true" />
              ) : (
                <Menu className="block h-6 w-6" aria-hidden="true" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="sm:hidden absolute bg-white w-full shadow-lg z-50 slide-in">
          <div className="pt-2 pb-3 space-y-1">
            <Link
              to="/"
              className={`block pl-3 pr-4 py-2 border-l-4 text-base font-medium ${
                location.pathname === '/'
                  ? 'border-primary-500 text-primary-700 bg-primary-50'
                  : 'border-transparent text-neutral-600 hover:bg-neutral-50 hover:border-neutral-300 hover:text-neutral-800'
              }`}
              onClick={() => setIsMenuOpen(false)}
            >
              Home
            </Link>
            <Link
              to="/routes"
              className={`block pl-3 pr-4 py-2 border-l-4 text-base font-medium ${
                location.pathname === '/routes' || location.pathname.startsWith('/routes/')
                  ? 'border-primary-500 text-primary-700 bg-primary-50'
                  : 'border-transparent text-neutral-600 hover:bg-neutral-50 hover:border-neutral-300 hover:text-neutral-800'
              }`}
              onClick={() => setIsMenuOpen(false)}
            >
              Routes
            </Link>
            <Link
              to="/report"
              className={`block pl-3 pr-4 py-2 border-l-4 text-base font-medium ${
                location.pathname === '/report'
                  ? 'border-primary-500 text-primary-700 bg-primary-50'
                  : 'border-transparent text-neutral-600 hover:bg-neutral-50 hover:border-neutral-300 hover:text-neutral-800'
              }`}
              onClick={() => setIsMenuOpen(false)}
            >
              Report Bus
            </Link>
            <Link
              to="/notifications"
              className={`block pl-3 pr-4 py-2 border-l-4 text-base font-medium ${
                location.pathname === '/notifications'
                  ? 'border-primary-500 text-primary-700 bg-primary-50'
                  : 'border-transparent text-neutral-600 hover:bg-neutral-50 hover:border-neutral-300 hover:text-neutral-800'
              }`}
              onClick={() => setIsMenuOpen(false)}
            >
              Notifications
            </Link>
            <Link
              to="/profile"
              className={`block pl-3 pr-4 py-2 border-l-4 text-base font-medium ${
                location.pathname === '/profile'
                  ? 'border-primary-500 text-primary-700 bg-primary-50'
                  : 'border-transparent text-neutral-600 hover:bg-neutral-50 hover:border-neutral-300 hover:text-neutral-800'
              }`}
              onClick={() => setIsMenuOpen(false)}
            >
              Profile
            </Link>
            {!isAuthenticated && (
              <Link
                to="/auth"
                className="block pl-3 pr-4 py-2 border-l-4 border-transparent text-base font-medium text-primary-600 hover:bg-neutral-50 hover:border-primary-300 hover:text-primary-800"
                onClick={() => setIsMenuOpen(false)}
              >
                Login / Register
              </Link>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;