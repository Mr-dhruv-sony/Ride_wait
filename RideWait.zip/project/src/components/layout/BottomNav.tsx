import { Link, useLocation } from 'react-router-dom';
import { Home, MapPin, BusFront, Bell, User } from 'lucide-react';
import { useAuthStore } from '../../stores/authStore';

const BottomNav = () => {
  const location = useLocation();
  const { isAuthenticated } = useAuthStore();

  return (
    <div className="sm:hidden fixed bottom-0 left-0 right-0 z-10 bg-white border-t border-neutral-200 px-2 py-2">
      <div className="flex justify-around">
        <Link
          to="/"
          className={`flex flex-col items-center justify-center w-full py-1 rounded-md ${
            location.pathname === '/' ? 'text-primary-600' : 'text-neutral-500'
          }`}
        >
          <Home className="h-6 w-6" />
          <span className="text-xs mt-1">Home</span>
        </Link>
        
        <Link
          to="/routes"
          className={`flex flex-col items-center justify-center w-full py-1 rounded-md ${
            location.pathname === '/routes' || location.pathname.startsWith('/routes/') 
              ? 'text-primary-600' 
              : 'text-neutral-500'
          }`}
        >
          <MapPin className="h-6 w-6" />
          <span className="text-xs mt-1">Routes</span>
        </Link>
        
        <Link
          to="/report"
          className={`flex flex-col items-center justify-center w-full py-1 rounded-md ${
            location.pathname === '/report' ? 'text-primary-600' : 'text-neutral-500'
          }`}
        >
          <BusFront className="h-6 w-6" />
          <span className="text-xs mt-1">Report</span>
        </Link>
        
        <Link
          to="/notifications"
          className={`flex flex-col items-center justify-center w-full py-1 rounded-md ${
            location.pathname === '/notifications' ? 'text-primary-600' : 'text-neutral-500'
          }`}
        >
          <Bell className="h-6 w-6" />
          <span className="text-xs mt-1">Alerts</span>
        </Link>
        
        <Link
          to={isAuthenticated ? "/profile" : "/auth"}
          className={`flex flex-col items-center justify-center w-full py-1 rounded-md ${
            location.pathname === '/profile' || location.pathname === '/auth' 
              ? 'text-primary-600' 
              : 'text-neutral-500'
          }`}
        >
          <User className="h-6 w-6" />
          <span className="text-xs mt-1">Profile</span>
        </Link>
      </div>
    </div>
  );
};

export default BottomNav;