import { useEffect, useState } from 'react';
import { Marker, useMap } from 'react-leaflet';
import L from 'leaflet';
import { useAuthStore } from '../../stores/authStore';

interface Position {
  lat: number;
  lng: number;
}

const createUserIcon = () => {
  return L.divIcon({
    className: 'custom-user-icon',
    html: `<div class="w-4 h-4 bg-primary-500 rounded-full border-2 border-white shadow-lg"></div>`,
    iconSize: [16, 16],
    iconAnchor: [8, 8],
  });
};

const LiveLocationMarker = () => {
  const [position, setPosition] = useState<Position | null>(null);
  const [watchId, setWatchId] = useState<number | null>(null);
  const map = useMap();
  const { isAuthenticated } = useAuthStore();

  useEffect(() => {
    if (!isAuthenticated) return;

    if (!navigator.geolocation) {
      console.log('Geolocation is not supported by your browser');
      return;
    }

    // Start watching position
    const id = navigator.geolocation.watchPosition(
      (pos) => {
        const newPos = {
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
        };
        setPosition(newPos);

        // Center map on first position
        if (!position) {
          map.setView(newPos, 15);
        }
      },
      (error) => {
        console.log('Error getting location:', error);
      },
      {
        enableHighAccuracy: true,
        timeout: 5000,
        maximumAge: 0,
      }
    );

    setWatchId(id);

    return () => {
      if (watchId) {
        navigator.geolocation.clearWatch(watchId);
      }
    };
  }, [map, isAuthenticated]);

  if (!position) return null;

  return <Marker position={position} icon={createUserIcon()} />;
};

export default LiveLocationMarker;