import { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline } from 'react-leaflet';
import L from 'leaflet';
import { format } from 'date-fns';
import { BusReport } from '../../stores/routesStore';
import LiveLocationMarker from './LiveLocationMarker';

// Correcting the import path for marker icons
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

interface RouteMapProps {
  reports: BusReport[];
  stops: string[];
}

// Mock coordinates for stops - in a real app, these would come from the API
const getStopCoordinates = (stopName: string, index: number, totalStops: number): [number, number] => {
  // This is just a demo function that returns fake coordinates based on the stop index
  // In a real app, you would use actual geocoded coordinates
  const baseLatitude = 12.9716;  // Base coordinates for Bangalore
  const baseLongitude = 77.5946;
  
  const latOffset = (index / (totalStops - 1)) * 0.05;
  const lngOffset = (index / (totalStops - 1)) * 0.05;
  
  return [baseLatitude + latOffset, baseLongitude + lngOffset];
};

const createBusIcon = (crowdLevel: string) => {
  let color = '';
  switch (crowdLevel) {
    case 'empty':
      color = '#22c55e'; // green
      break;
    case 'moderate':
      color = '#3b82f6'; // blue
      break;
    case 'crowded':
      color = '#f59e0b'; // yellow
      break;
    case 'full':
      color = '#ef4444'; // red
      break;
    default:
      color = '#6b7280'; // gray
  }
  
  return L.divIcon({
    className: 'custom-bus-icon',
    html: `<div class="w-6 h-6 rounded-full bg-white shadow-lg flex items-center justify-center">
      <div class="w-4 h-4 rounded-full" style="background-color: ${color}"></div>
    </div>`,
    iconSize: [24, 24],
    iconAnchor: [12, 12],
  });
};

const RouteMap = ({ reports, stops }: RouteMapProps) => {
  const [stopCoordinates, setStopCoordinates] = useState<[number, number][]>([]);
  
  useEffect(() => {
    // Generate coordinates for stops
    const coordinates = stops.map((stop, index) => 
      getStopCoordinates(stop, index, stops.length)
    );
    setStopCoordinates(coordinates);
  }, [stops]);
  
  // Calculate the center of the map based on reports or stops
  const getMapCenter = () => {
    if (reports.length > 0) {
      return [reports[0].location.lat, reports[0].location.lng] as [number, number];
    }
    if (stopCoordinates.length > 0) {
      return stopCoordinates[0];
    }
    return [12.9716, 77.5946] as [number, number]; // Default to Bangalore
  };
  
  return (
    <div className="map-container">
      {(reports.length > 0 || stopCoordinates.length > 0) && (
        <MapContainer 
          center={getMapCenter()} 
          zoom={13} 
          scrollWheelZoom={true}
          style={{ height: '100%', width: '100%' }}
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          
          {/* Live user location */}
          <LiveLocationMarker />
          
          {/* Route line connecting stops */}
          {stopCoordinates.length > 0 && (
            <Polyline 
              positions={stopCoordinates}
              color="#0077ff"
              weight={3}
              opacity={0.7}
              dashArray="5, 10"
            />
          )}
          
          {/* Stops markers */}
          {stopCoordinates.map((coords, index) => (
            <Marker 
              key={`stop-${index}`}
              position={coords}
              icon={L.divIcon({
                className: 'custom-stop-icon',
                html: `<div class="bg-white rounded-full border-2 border-primary-600 w-3 h-3"></div>`,
                iconSize: [12, 12],
                iconAnchor: [6, 6],
              })}
            >
              <Popup>
                <div className="text-sm">
                  <strong>{stops[index]}</strong>
                </div>
              </Popup>
            </Marker>
          ))}
          
          {/* Bus reports markers */}
          {reports.map((report) => (
            <Marker
              key={report.id}
              position={[report.location.lat, report.location.lng]}
              icon={createBusIcon(report.crowdLevel)}
            >
              <Popup>
                <div className="text-sm">
                  <strong>Reported by:</strong> {report.userName}<br />
                  <strong>Location:</strong> {report.location.locationName}<br />
                  <strong>Status:</strong> {report.crowdLevel}<br />
                  <strong>Time:</strong> {format(report.timestamp, 'h:mm a')}
                  {report.message && (
                    <>
                      <br />
                      <strong>Note:</strong> {report.message}
                    </>
                  )}
                </div>
              </Popup>
            </Marker>
          ))}
        </MapContainer>
      )}
    </div>
  );
};

export default RouteMap;