import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Star, ChevronLeft, MapPin, Clock, UserCheck, Users, MessageCircle } from 'lucide-react';
import { format, formatDistanceToNow } from 'date-fns';
import { useRoutesStore, BusRoute, BusReport } from '../stores/routesStore';
import RouteMap from '../components/map/RouteMap';

const RouteDetailPage = () => {
  const { routeId } = useParams<{ routeId: string }>();
  const { routes, reports, fetchRoutes, fetchReports, toggleFavorite, isLoading } = useRoutesStore();
  const [route, setRoute] = useState<BusRoute | null>(null);
  
  useEffect(() => {
    if (routes.length === 0) {
      fetchRoutes();
    } else {
      const foundRoute = routes.find(r => r.id === routeId);
      setRoute(foundRoute || null);
    }
  }, [routeId, routes, fetchRoutes]);
  
  useEffect(() => {
    if (routeId) {
      fetchReports(routeId);
    }
  }, [routeId, fetchReports]);

  const handleToggleFavorite = () => {
    if (routeId) {
      toggleFavorite(routeId);
    }
  };

  const getCrowdLevelClass = (level: string) => {
    switch (level) {
      case 'empty':
        return 'bg-green-100 text-green-800';
      case 'moderate':
        return 'bg-blue-100 text-blue-800';
      case 'crowded':
        return 'bg-yellow-100 text-yellow-800';
      case 'full':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (isLoading || !route) {
    return (
      <div className="flex justify-center py-10">
        <div className="animate-pulse-slow text-primary-600">Loading route details...</div>
      </div>
    );
  }

  return (
    <div className="py-6 space-y-6 pb-20">
      <div className="flex items-center space-x-3">
        <Link to="/routes" className="p-2 rounded-full bg-white shadow-soft hover:bg-neutral-50">
          <ChevronLeft className="h-5 w-5 text-neutral-600" />
        </Link>
        <h1 className="text-2xl font-bold text-neutral-800">Route {route.number}</h1>
      </div>
      
      <div className="bg-white rounded-lg shadow-soft border border-neutral-100 overflow-hidden">
        <div className="p-4">
          <div className="flex items-center justify-between">
            <h2 className="font-medium text-lg text-neutral-800">{route.name}</h2>
            <button
              onClick={handleToggleFavorite}
              className={`p-2 rounded-full ${
                route.isFavorite 
                  ? 'text-accent-500 hover:bg-accent-50' 
                  : 'text-neutral-400 hover:bg-neutral-100'
              }`}
            >
              <Star className="h-5 w-5" fill={route.isFavorite ? 'currentColor' : 'none'} />
            </button>
          </div>
          
          <div className="flex flex-col sm:flex-row sm:items-center text-sm text-neutral-600 mt-2 space-y-2 sm:space-y-0 sm:space-x-4">
            <div className="flex items-center">
              <MapPin className="h-4 w-4 mr-1 text-neutral-500" />
              <span>{route.source} to {route.destination}</span>
            </div>
            <div className="flex items-center">
              <Clock className="h-4 w-4 mr-1 text-neutral-500" />
              <span>{route.operatingHours}</span>
            </div>
          </div>
          
          <div className="mt-4">
            <h3 className="font-medium text-neutral-800 mb-2">Stops</h3>
            <div className="space-y-2">
              {route.stops.map((stop, index) => (
                <div key={index} className="flex items-center">
                  <div className="h-6 w-6 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center text-xs font-medium mr-2">
                    {index + 1}
                  </div>
                  <span className="text-neutral-600">{stop}</span>
                </div>
              ))}
            </div>
          </div>
          
          <div className="mt-4 pt-4 border-t border-neutral-100">
            <div className="flex justify-between items-center mb-3">
              <h3 className="font-medium text-neutral-800">Live Map</h3>
              <span className="text-xs bg-primary-100 text-primary-700 px-2 py-1 rounded-full">
                Updated {reports.length > 0 ? formatDistanceToNow(reports[0]?.timestamp, { addSuffix: true }) : 'recently'}
              </span>
            </div>
            
            <div className="h-64 bg-neutral-100 rounded-lg overflow-hidden">
              <RouteMap reports={reports} stops={route.stops} />
            </div>
          </div>
        </div>
      </div>
      
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h3 className="font-medium text-lg text-neutral-800">Live Reports</h3>
          <Link
            to="/report"
            className="px-4 py-2 rounded-md font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
          >
            Report Location
          </Link>
        </div>
        
        {reports.length === 0 ? (
          <div className="text-center py-8 bg-white rounded-lg shadow-soft border border-neutral-100">
            <Users className="h-12 w-12 text-neutral-400 mx-auto mb-3" />
            <p className="text-neutral-600">No recent reports for this route.</p>
            <p className="text-neutral-500 text-sm mt-1">Be the first to report!</p>
          </div>
        ) : (
          <div className="space-y-3">
            {reports.map((report) => (
              <div 
                key={report.id} 
                className="bg-white rounded-lg shadow-soft border border-neutral-100 p-4 fade-in"
              >
                <div className="flex items-start">
                  <div className="flex-shrink-0">
                    <div className="h-10 w-10 rounded-full bg-primary-100 text-primary-600 flex items-center justify-center">
                      <UserCheck className="h-5 w-5" />
                    </div>
                  </div>
                  
                  <div className="ml-3 flex-1">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-medium text-neutral-800">{report.userName}</p>
                        <p className="text-sm text-neutral-500">
                          Reported from {report.location.locationName} • {formatDistanceToNow(report.timestamp, { addSuffix: true })}
                        </p>
                      </div>
                      <span className={`text-xs px-2 py-1 rounded-full ${getCrowdLevelClass(report.crowdLevel)}`}>
                        {report.crowdLevel.charAt(0).toUpperCase() + report.crowdLevel.slice(1)}
                      </span>
                    </div>
                    
                    {report.message && (
                      <div className="mt-2 flex items-start">
                        <MessageCircle className="h-4 w-4 text-neutral-500 mt-0.5 mr-1.5" />
                        <p className="text-neutral-700">{report.message}</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default RouteDetailPage;