import { useState } from 'react';
import { LogOut, User, Award, BusFront, MapPin, Edit, Camera, Save } from 'lucide-react';
import { useAuthStore } from '../stores/authStore';

const ProfilePage = () => {
  const { user, logout } = useAuthStore();
  const [isEditing, setIsEditing] = useState(false);
  const [editedName, setEditedName] = useState(user?.name || '');
  
  const [activities] = useState([
    { type: 'report', route: 'Route 401', location: 'Tech Park', time: '2 hours ago' },
    { type: 'reputation', points: 10, reason: 'Accurate report on Route 225', time: '1 day ago' },
    { type: 'report', route: 'Route 103', location: 'Beach Road', time: '3 days ago' },
    { type: 'reputation', points: 5, reason: 'Helpful bus status update', time: '1 week ago' },
  ]);
  
  const handleSaveProfile = () => {
    // In a real app, this would update the user profile in the backend
    setIsEditing(false);
  };
  
  const handleLogout = () => {
    logout();
  };
  
  if (!user) {
    return null;
  }
  
  return (
    <div className="py-6 space-y-8 pb-20">
      <div className="bg-white rounded-lg shadow-soft border border-neutral-100 overflow-hidden">
        <div className="bg-gradient-to-r from-primary-600 to-primary-700 h-32"></div>
        
        <div className="px-4 sm:px-6 -mt-16">
          <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between">
            <div className="flex items-center">
              <div className="relative">
                <div className="h-24 w-24 rounded-full border-4 border-white bg-neutral-200 flex items-center justify-center overflow-hidden">
                  {user.photoURL ? (
                    <img src={user.photoURL} alt={user.name} className="h-full w-full object-cover" />
                  ) : (
                    <User className="h-12 w-12 text-neutral-400" />
                  )}
                </div>
                
                {isEditing && (
                  <button className="absolute bottom-0 right-0 p-1.5 rounded-full bg-primary-600 text-white hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">
                    <Camera className="h-4 w-4" />
                  </button>
                )}
              </div>
              
              <div className="ml-4 mt-10 sm:mt-0">
                {isEditing ? (
                  <input
                    type="text"
                    value={editedName}
                    onChange={(e) => setEditedName(e.target.value)}
                    className="border-b border-primary-300 bg-transparent text-xl font-bold text-neutral-800 focus:outline-none focus:border-primary-500 pb-1"
                  />
                ) : (
                  <h1 className="text-xl font-bold text-neutral-800">{user.name}</h1>
                )}
                <p className="text-sm text-neutral-500">{user.email}</p>
              </div>
            </div>
            
            <div className="mt-4 sm:mt-0 flex space-x-2">
              {isEditing ? (
                <button
                  onClick={handleSaveProfile}
                  className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                >
                  <Save className="h-4 w-4 mr-1.5" />
                  Save
                </button>
              ) : (
                <button
                  onClick={() => setIsEditing(true)}
                  className="inline-flex items-center px-4 py-2 border border-neutral-300 rounded-md shadow-sm text-sm font-medium text-neutral-700 bg-white hover:bg-neutral-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                >
                  <Edit className="h-4 w-4 mr-1.5" />
                  Edit Profile
                </button>
              )}
              
              <button
                onClick={handleLogout}
                className="inline-flex items-center px-4 py-2 border border-neutral-300 rounded-md shadow-sm text-sm font-medium text-neutral-700 bg-white hover:bg-neutral-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
              >
                <LogOut className="h-4 w-4 mr-1.5" />
                Logout
              </button>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8 pb-6">
            <div className="bg-primary-50 rounded-lg p-4 flex items-center">
              <div className="h-12 w-12 rounded-full bg-primary-100 text-primary-600 flex items-center justify-center">
                <Award className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <h3 className="text-xs uppercase tracking-wider text-neutral-500 font-medium">Reputation</h3>
                <p className="text-2xl font-bold text-primary-700">{user.reputation} pts</p>
              </div>
            </div>
            
            <div className="bg-secondary-50 rounded-lg p-4 flex items-center">
              <div className="h-12 w-12 rounded-full bg-secondary-100 text-secondary-600 flex items-center justify-center">
                <BusFront className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <h3 className="text-xs uppercase tracking-wider text-neutral-500 font-medium">Reports</h3>
                <p className="text-2xl font-bold text-secondary-700">{user.reportsCount}</p>
              </div>
            </div>
            
            <div className="bg-accent-50 rounded-lg p-4 flex items-center">
              <div className="h-12 w-12 rounded-full bg-accent-100 text-accent-600 flex items-center justify-center">
                <MapPin className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <h3 className="text-xs uppercase tracking-wider text-neutral-500 font-medium">Routes</h3>
                <p className="text-2xl font-bold text-accent-700">5</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="space-y-4">
        <h2 className="text-xl font-semibold text-neutral-800">Recent Activity</h2>
        
        <div className="bg-white rounded-lg shadow-soft border border-neutral-100 overflow-hidden">
          <ul className="divide-y divide-neutral-200">
            {activities.map((activity, index) => (
              <li key={index} className="p-4 hover:bg-neutral-50">
                <div className="flex items-start">
                  <div className="flex-shrink-0">
                    {activity.type === 'report' ? (
                      <div className="h-10 w-10 rounded-full bg-primary-100 text-primary-600 flex items-center justify-center">
                        <BusFront className="h-5 w-5" />
                      </div>
                    ) : (
                      <div className="h-10 w-10 rounded-full bg-accent-100 text-accent-600 flex items-center justify-center">
                        <Award className="h-5 w-5" />
                      </div>
                    )}
                  </div>
                  
                  <div className="ml-3 flex-1">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-medium text-neutral-800">
                          {activity.type === 'report' 
                            ? `Reported bus location on ${activity.route}`
                            : `Earned ${activity.points} reputation points`
                          }
                        </p>
                        <p className="text-sm text-neutral-600">
                          {activity.type === 'report' 
                            ? `Location: ${activity.location}`
                            : activity.reason
                          }
                        </p>
                        <p className="text-xs text-neutral-500 mt-1">{activity.time}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;