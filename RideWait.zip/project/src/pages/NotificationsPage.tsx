import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Bell, AlertTriangle, Info, RefreshCw, Trash2, CheckCircle } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { useNotificationsStore } from '../stores/notificationsStore';

const NotificationsPage = () => {
  const { 
    notifications, 
    isLoading, 
    fetchNotifications, 
    markAsRead, 
    markAllAsRead, 
    deleteNotification 
  } = useNotificationsStore();
  
  useEffect(() => {
    fetchNotifications();
  }, [fetchNotifications]);
  
  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'alert':
        return <AlertTriangle className="h-5 w-5 text-error-500" />;
      case 'info':
        return <Info className="h-5 w-5 text-primary-500" />;
      case 'update':
        return <RefreshCw className="h-5 w-5 text-secondary-600" />;
      default:
        return <Bell className="h-5 w-5 text-neutral-500" />;
    }
  };
  
  const getNotificationClass = (type: string) => {
    switch (type) {
      case 'alert':
        return 'border-l-error-500';
      case 'info':
        return 'border-l-primary-500';
      case 'update':
        return 'border-l-secondary-600';
      default:
        return 'border-l-neutral-500';
    }
  };
  
  if (isLoading) {
    return (
      <div className="flex justify-center py-10">
        <div className="animate-pulse-slow text-primary-600">Loading notifications...</div>
      </div>
    );
  }
  
  return (
    <div className="py-6 space-y-6 pb-20">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-neutral-800">Notifications</h1>
        
        {notifications.length > 0 && (
          <button
            onClick={markAllAsRead}
            className="text-sm text-primary-600 hover:text-primary-700 font-medium flex items-center"
          >
            <CheckCircle className="h-4 w-4 mr-1" />
            Mark all as read
          </button>
        )}
      </div>
      
      {notifications.length === 0 ? (
        <div className="text-center py-10 bg-white rounded-lg shadow-soft border border-neutral-100">
          <Bell className="h-12 w-12 text-neutral-400 mx-auto mb-3" />
          <p className="text-neutral-600">No notifications yet.</p>
          <p className="text-neutral-500 text-sm mt-1">We'll notify you about important updates and alerts.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {notifications.map((notification) => (
            <div 
              key={notification.id} 
              className={`bg-white rounded-lg shadow-soft border border-neutral-100 border-l-4 ${
                getNotificationClass(notification.type)
              } p-4 ${
                !notification.isRead ? 'bg-primary-50' : ''
              } fade-in`}
            >
              <div className="flex items-start">
                <div className="flex-shrink-0 mt-0.5">
                  {getNotificationIcon(notification.type)}
                </div>
                
                <div className="ml-3 flex-1">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className={`font-medium ${!notification.isRead ? 'text-neutral-900' : 'text-neutral-800'}`}>
                        {notification.title}
                      </p>
                      <p className={`text-sm ${!notification.isRead ? 'text-neutral-700' : 'text-neutral-600'}`}>
                        {notification.message}
                      </p>
                      <p className="text-xs text-neutral-500 mt-1">
                        {formatDistanceToNow(notification.timestamp, { addSuffix: true })}
                      </p>
                    </div>
                    
                    <div className="flex space-x-1">
                      {!notification.isRead && (
                        <button
                          onClick={() => markAsRead(notification.id)}
                          className="p-1 rounded-full text-neutral-500 hover:text-primary-600 hover:bg-primary-50"
                        >
                          <CheckCircle className="h-5 w-5" />
                        </button>
                      )}
                      
                      <button
                        onClick={() => deleteNotification(notification.id)}
                        className="p-1 rounded-full text-neutral-500 hover:text-error-600 hover:bg-error-50"
                      >
                        <Trash2 className="h-5 w-5" />
                      </button>
                    </div>
                  </div>
                  
                  {notification.routeId && (
                    <div className="mt-2">
                      <Link
                        to={`/routes/${notification.routeId}`}
                        className="inline-flex items-center px-3 py-1 text-xs font-medium rounded-full bg-primary-100 text-primary-700 hover:bg-primary-200"
                      >
                        View Route
                      </Link>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default NotificationsPage;