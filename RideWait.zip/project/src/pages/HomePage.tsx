import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Star, MapPin, Clock, Users, AlertTriangle } from 'lucide-react';
import { useRoutesStore, BusRoute } from '../stores/routesStore';
import { useAuthStore } from '../stores/authStore';

const HomePage = () => {
  const { routes, fetchRoutes, searchRoutes, favoriteRoutes } = useRoutesStore();
  const { isAuthenticated } = useAuthStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const initPage = async () => {
      await fetchRoutes();
      setLoading(false);
    };
    
    initPage();
  }, [fetchRoutes]);
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    searchRoutes(searchTerm);
  };
  
  const getFavoriteRoutes = (): BusRoute[] => {
    return routes.filter(route => favoriteRoutes.includes(route.id));
  };
  
  const getRecentRoutes = (): BusRoute[] => {
    // In a real app, this would be based on user history
    // For now, just return the first 3 routes
    return routes.slice(0, 3);
  };

  return (
    <div className="py-6 space-y-8 pb-20">
      <section className="text-center px-4 py-10 bg-gradient-to-r from-primary-600 to-primary-700 rounded-xl text-white mb-8">
        <h1 className="text-3xl font-bold mb-4 slide-up">RideWait</h1>
        <p className="text-lg opacity-90 mb-8 slide-up">
          Crowd-sourced transit tracking to save your time
        </p>
        
        <form onSubmit={handleSearch} className="max-w-md mx-auto slide-up">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-neutral-400" />
            </div>
            <input
              type="text"
              placeholder="Search routes, stops or bus numbers..."
              className="block w-full pl-10 pr-3 py-3 border border-neutral-300 rounded-lg bg-white text-neutral-900 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <button
              type="submit"
              className="absolute inset-y-0 right-0 px-4 text-white bg-primary-500 hover:bg-primary-600 rounded-r-lg"
            >
              Search
            </button>
          </div>
        </form>
      </section>
      
      {loading ? (
        <div className="flex justify-center py-10">
          <div className="animate-pulse-slow text-primary-600">Loading...</div>
        </div>
      ) : (
        <>
          {isAuthenticated && getFavoriteRoutes().length > 0 && (
            <section className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold text-neutral-800 flex items-center">
                  <Star className="h-5 w-5 text-accent-500 mr-2" />
                  Favorite Routes
                </h2>
                <Link to="/routes" className="text-primary-600 text-sm font-medium hover:text-primary-700">
                  View All
                </Link>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {getFavoriteRoutes().map(route => (
                  <Link
                    key={route.id}
                    to={`/routes/${route.id}`}
                    className="bg-white rounded-lg shadow-soft hover:shadow-medium transition-shadow p-4 border border-neutral-100"
                  >
                    <div className="flex items-start">
                      <div className="h-10 w-10 flex items-center justify-center bg-primary-100 text-primary-700 rounded-full flex-shrink-0">
                        <span className="font-semibold text-sm">{route.number}</span>
                      </div>
                      <div className="ml-3">
                        <h3 className="font-medium text-neutral-800">{route.name}</h3>
                        <div className="flex items-center text-sm text-neutral-500 mt-1">
                          <MapPin className="h-4 w-4 mr-1" />
                          <span>{route.source} to {route.destination}</span>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </section>
          )}
          
          <section className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold text-neutral-800 flex items-center">
                <Clock className="h-5 w-5 text-primary-600 mr-2" />
                Recent Routes
              </h2>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {getRecentRoutes().map(route => (
                <Link
                  key={route.id}
                  to={`/routes/${route.id}`}
                  className="bg-white rounded-lg shadow-soft hover:shadow-medium transition-shadow p-4 border border-neutral-100"
                >
                  <div className="flex items-start">
                    <div className="h-10 w-10 flex items-center justify-center bg-primary-100 text-primary-700 rounded-full flex-shrink-0">
                      <span className="font-semibold text-sm">{route.number}</span>
                    </div>
                    <div className="ml-3">
                      <h3 className="font-medium text-neutral-800">{route.name}</h3>
                      <div className="flex items-center text-sm text-neutral-500 mt-1">
                        <MapPin className="h-4 w-4 mr-1" />
                        <span>{route.source} to {route.destination}</span>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </section>
          
          <section className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold text-neutral-800 flex items-center">
                <AlertTriangle className="h-5 w-5 text-error-500 mr-2" />
                Service Alerts
              </h2>
              <Link to="/notifications" className="text-primary-600 text-sm font-medium hover:text-primary-700">
                View All
              </Link>
            </div>
            
            <div className="bg-white rounded-lg shadow-soft p-4 border border-neutral-100">
              <div className="space-y-4">
                <div className="border-l-4 border-error-500 pl-3 py-1">
                  <h3 className="font-medium text-neutral-800">Route 401 Delay</h3>
                  <p className="text-sm text-neutral-600">15-minute delay due to heavy traffic near Tech Park</p>
                  <p className="text-xs text-neutral-400 mt-1">Updated 30 minutes ago</p>
                </div>
                
                <div className="border-l-4 border-accent-500 pl-3 py-1">
                  <h3 className="font-medium text-neutral-800">Weekend Schedule Change</h3>
                  <p className="text-sm text-neutral-600">Route 103 will operate on a reduced frequency during the weekend</p>
                  <p className="text-xs text-neutral-400 mt-1">Updated 2 days ago</p>
                </div>
              </div>
            </div>
          </section>
          
          <section className="mt-8">
            <div className="bg-neutral-100 rounded-lg p-6">
              <h2 className="text-xl font-semibold text-neutral-800 mb-4">How RideWait Works</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white p-4 rounded-lg shadow-soft">
                  <div className="h-10 w-10 flex items-center justify-center bg-primary-100 text-primary-700 rounded-full mb-3">
                    <Users className="h-5 w-5" />
                  </div>
                  <h3 className="font-medium text-lg mb-2">Community Reports</h3>
                  <p className="text-neutral-600 text-sm">
                    Passengers report bus locations in real-time, creating a crowd-sourced tracking system.
                  </p>
                </div>
                
                <div className="bg-white p-4 rounded-lg shadow-soft">
                  <div className="h-10 w-10 flex items-center justify-center bg-primary-100 text-primary-700 rounded-full mb-3">
                    <MapPin className="h-5 w-5" />
                  </div>
                  <h3 className="font-medium text-lg mb-2">Live Updates</h3>
                  <p className="text-neutral-600 text-sm">
                    Track bus arrivals in real-time and plan your journey accordingly.
                  </p>
                </div>
                
                <div className="bg-white p-4 rounded-lg shadow-soft">
                  <div className="h-10 w-10 flex items-center justify-center bg-primary-100 text-primary-700 rounded-full mb-3">
                    <Clock className="h-5 w-5" />
                  </div>
                  <h3 className="font-medium text-lg mb-2">Save Time</h3>
                  <p className="text-neutral-600 text-sm">
                    Reduce waiting time by 60-70% with accurate arrival information.
                  </p>
                </div>
              </div>
            </div>
          </section>
        </>
      )}
    </div>
  );
};

export default HomePage;