import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Star, MapPin, Clock, Bus } from 'lucide-react';
import { useRoutesStore } from '../stores/routesStore';

const RoutesPage = () => {
  const { routes, fetchRoutes, toggleFavorite, isLoading } = useRoutesStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredRoutes, setFilteredRoutes] = useState(routes);

  useEffect(() => {
    fetchRoutes();
  }, [fetchRoutes]);

  useEffect(() => {
    if (searchTerm.trim() === '') {
      setFilteredRoutes(routes);
    } else {
      const lowercasedFilter = searchTerm.toLowerCase();
      const filtered = routes.filter(route => 
        route.number.toLowerCase().includes(lowercasedFilter) ||
        route.name.toLowerCase().includes(lowercasedFilter) ||
        route.source.toLowerCase().includes(lowercasedFilter) ||
        route.destination.toLowerCase().includes(lowercasedFilter) ||
        route.stops.some(stop => stop.toLowerCase().includes(lowercasedFilter))
      );
      setFilteredRoutes(filtered);
    }
  }, [searchTerm, routes]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // The search is already handled by the useEffect above
  };

  const handleToggleFavorite = (e: React.MouseEvent, routeId: string) => {
    e.preventDefault();
    e.stopPropagation();
    toggleFavorite(routeId);
  };

  return (
    <div className="py-6 space-y-6 pb-20">
      <h1 className="text-2xl font-bold text-neutral-800">All Routes</h1>
      
      <form onSubmit={handleSearch} className="mb-6">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-neutral-400" />
          </div>
          <input
            type="text"
            placeholder="Search routes, stops or bus numbers..."
            className="block w-full pl-10 pr-3 py-3 border border-neutral-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </form>
      
      {isLoading ? (
        <div className="flex justify-center py-10">
          <div className="animate-pulse-slow text-primary-600">Loading routes...</div>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredRoutes.length === 0 ? (
            <div className="text-center py-10">
              <Bus className="h-12 w-12 text-neutral-400 mx-auto mb-4" />
              <p className="text-neutral-600">No routes found matching your search.</p>
              <p className="text-neutral-500 text-sm mt-1">Try a different search term or browse all routes.</p>
            </div>
          ) : (
            filteredRoutes.map(route => (
              <Link
                key={route.id}
                to={`/routes/${route.id}`}
                className="block bg-white rounded-lg shadow-soft hover:shadow-medium transition-shadow border border-neutral-100 overflow-hidden fade-in"
              >
                <div className="p-4">
                  <div className="flex items-start">
                    <div className="h-12 w-12 flex items-center justify-center bg-primary-100 text-primary-700 rounded-full flex-shrink-0">
                      <span className="font-semibold">{route.number}</span>
                    </div>
                    <div className="ml-4 flex-1">
                      <div className="flex items-center justify-between">
                        <h3 className="font-medium text-lg text-neutral-800">{route.name}</h3>
                        <button
                          onClick={(e) => handleToggleFavorite(e, route.id)}
                          className={`p-2 rounded-full ${
                            route.isFavorite 
                              ? 'text-accent-500 hover:bg-accent-50' 
                              : 'text-neutral-400 hover:bg-neutral-100'
                          }`}
                        >
                          <Star className="h-5 w-5" fill={route.isFavorite ? 'currentColor' : 'none'} />
                        </button>
                      </div>
                      
                      <div className="flex flex-col sm:flex-row sm:items-center text-sm text-neutral-600 mt-2 space-y-2 sm:space-y-0 sm:space-x-4">
                        <div className="flex items-center">
                          <MapPin className="h-4 w-4 mr-1 text-neutral-500" />
                          <span>{route.source} to {route.destination}</span>
                        </div>
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 mr-1 text-neutral-500" />
                          <span>{route.operatingHours}</span>
                        </div>
                      </div>
                      
                      <div className="mt-3">
                        <div className="text-xs text-neutral-500">Frequency: {route.frequency}</div>
                        <div className="flex flex-wrap gap-2 mt-2">
                          {route.stops.map((stop, index) => (
                            <span 
                              key={index}
                              className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-neutral-100 text-neutral-700"
                            >
                              {stop}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
            ))
          )}
        </div>
      )}
    </div>
  );
};

export default RoutesPage;