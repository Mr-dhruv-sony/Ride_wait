import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { MapPin, Bus, Users, Check, ChevronDown } from 'lucide-react';
import { useRoutesStore, BusRoute } from '../stores/routesStore';
import { useAuthStore } from '../stores/authStore';

const crowdLevels = [
  { value: 'empty', label: 'Empty', description: 'Plenty of seats available' },
  { value: 'moderate', label: 'Moderate', description: 'Some seats available' },
  { value: 'crowded', label: 'Crowded', description: 'Standing room only' },
  { value: 'full', label: 'Full', description: 'Very crowded, might skip stops' },
];

const ReportPage = () => {
  const navigate = useNavigate();
  const { routes, fetchRoutes, addReport } = useRoutesStore();
  const { user } = useAuthStore();
  
  const [selectedRoute, setSelectedRoute] = useState<BusRoute | null>(null);
  const [showRouteDropdown, setShowRouteDropdown] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState('');
  const [selectedCrowdLevel, setSelectedCrowdLevel] = useState('moderate');
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionSuccess, setSubmissionSuccess] = useState(false);
  const [currentLocation, setCurrentLocation] = useState<{ lat: number; lng: number } | null>(null);
  
  useEffect(() => {
    if (routes.length === 0) {
      fetchRoutes();
    }
  }, [fetchRoutes, routes.length]);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCurrentLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
        },
        (error) => {
          console.error('Error getting location:', error);
        },
        {
          enableHighAccuracy: true,
          timeout: 5000,
          maximumAge: 0,
        }
      );
    }
  }, []);
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedRoute || !selectedLocation || !selectedCrowdLevel || !user || !currentLocation) {
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      await addReport({
        routeId: selectedRoute.id,
        userId: user.id,
        userName: user.name,
        userReputation: user.reputation,
        location: {
          lat: currentLocation.lat,
          lng: currentLocation.lng,
          locationName: selectedLocation,
        },
        crowdLevel: selectedCrowdLevel as any,
        message: message.trim() !== '' ? message : undefined,
      });
      
      setSubmissionSuccess(true);
      
      // Redirect after a short delay
      setTimeout(() => {
        navigate(`/routes/${selectedRoute.id}`);
      }, 2000);
    } catch (error) {
      console.error('Error submitting report:', error);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const getCrowdLevelClass = (level: string) => {
    switch (level) {
      case 'empty':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'moderate':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'crowded':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'full':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };
  
  if (!currentLocation) {
    return (
      <div className="py-8 flex flex-col items-center justify-center text-center">
        <div className="h-16 w-16 rounded-full bg-primary-100 flex items-center justify-center mb-4">
          <MapPin className="h-8 w-8 text-primary-600 animate-pulse" />
        </div>
        <h1 className="text-2xl font-bold text-neutral-800 mb-2">Getting Location</h1>
        <p className="text-neutral-600">
          Please enable location services to report bus status.
        </p>
      </div>
    );
  }
  
  if (submissionSuccess) {
    return (
      <div className="py-8 flex flex-col items-center justify-center text-center slide-up">
        <div className="h-16 w-16 rounded-full bg-green-100 flex items-center justify-center mb-4">
          <Check className="h-8 w-8 text-green-600" />
        </div>
        <h1 className="text-2xl font-bold text-neutral-800 mb-2">Thank You!</h1>
        <p className="text-neutral-600 mb-4">
          Your report has been submitted successfully.
        </p>
        <p className="text-neutral-500 text-sm">
          Redirecting to route details...
        </p>
      </div>
    );
  }
  
  return (
    <div className="py-6 space-y-6 pb-20">
      <h1 className="text-2xl font-bold text-neutral-800">Report Bus Location</h1>
      
      <div className="bg-white rounded-lg shadow-soft border border-neutral-100 p-4">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="route" className="block text-sm font-medium text-neutral-700 mb-1">
              Select Route
            </label>
            <div className="relative">
              <button
                type="button"
                className="w-full bg-white border border-neutral-300 rounded-md py-3 px-4 flex items-center justify-between focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                onClick={() => setShowRouteDropdown(!showRouteDropdown)}
              >
                {selectedRoute ? (
                  <div className="flex items-center">
                    <div className="h-6 w-6 flex items-center justify-center bg-primary-100 text-primary-700 rounded-full mr-2">
                      <span className="text-xs font-semibold">{selectedRoute.number}</span>
                    </div>
                    <span>{selectedRoute.name}</span>
                  </div>
                ) : (
                  <span className="text-neutral-500">Select a route</span>
                )}
                <ChevronDown className="h-5 w-5 text-neutral-400" />
              </button>
              
              {showRouteDropdown && (
                <div className="absolute z-10 mt-1 w-full bg-white shadow-lg rounded-md max-h-60 overflow-auto fade-in">
                  <ul className="py-1">
                    {routes.map(route => (
                      <li key={route.id}>
                        <button
                          type="button"
                          className="w-full text-left px-4 py-2 hover:bg-neutral-100 flex items-center"
                          onClick={() => {
                            setSelectedRoute(route);
                            setShowRouteDropdown(false);
                            setSelectedLocation('');
                          }}
                        >
                          <div className="h-6 w-6 flex items-center justify-center bg-primary-100 text-primary-700 rounded-full mr-2">
                            <span className="text-xs font-semibold">{route.number}</span>
                          </div>
                          <span>{route.name}</span>
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
          
          {selectedRoute && (
            <div>
              <label htmlFor="location" className="block text-sm font-medium text-neutral-700 mb-1">
                Current Location
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <MapPin className="h-5 w-5 text-neutral-400" />
                </div>
                <select
                  id="location"
                  value={selectedLocation}
                  onChange={(e) => setSelectedLocation(e.target.value)}
                  className="block w-full pl-10 pr-3 py-3 border border-neutral-300 rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                  required
                >
                  <option value="">Select your current stop</option>
                  {selectedRoute.stops.map((stop, index) => (
                    <option key={index} value={stop}>
                      {stop}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}
          
          {selectedRoute && selectedLocation && (
            <>
              <div>
                <label className="block text-sm font-medium text-neutral-700 mb-1">
                  Crowd Level
                </label>
                <div className="grid grid-cols-2 gap-3">
                  {crowdLevels.map((level) => (
                    <div key={level.value}>
                      <input
                        type="radio"
                        id={`crowd-${level.value}`}
                        name="crowdLevel"
                        value={level.value}
                        checked={selectedCrowdLevel === level.value}
                        onChange={() => setSelectedCrowdLevel(level.value)}
                        className="sr-only"
                      />
                      <label
                        htmlFor={`crowd-${level.value}`}
                        className={`cursor-pointer block p-3 border rounded-md ${
                          selectedCrowdLevel === level.value
                            ? getCrowdLevelClass(level.value) + ' ring-2 ring-offset-2 ring-primary-500'
                            : 'border-neutral-300 bg-white hover:bg-neutral-50'
                        }`}
                      >
                        <div className="flex items-center">
                          <Users className="h-5 w-5 mr-2" />
                          <div>
                            <p className="font-medium">{level.label}</p>
                            <p className="text-xs opacity-75">{level.description}</p>
                          </div>
                        </div>
                      </label>
                    </div>
                  ))}
                </div>
              </div>
              
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-neutral-700 mb-1">
                  Additional Notes (Optional)
                </label>
                <textarea
                  id="message"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  rows={3}
                  className="block w-full px-3 py-2 border border-neutral-300 rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                  placeholder="Any additional information about the bus..."
                />
              </div>
              
              <div>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full flex items-center justify-center px-4 py-3 border border-transparent rounded-md shadow-sm text-base font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isSubmitting ? (
                    <span>Submitting...</span>
                  ) : (
                    <span className="flex items-center">
                      <Bus className="h-5 w-5 mr-2" />
                      Submit Report
                    </span>
                  )}
                </button>
              </div>
            </>
          )}
        </form>
      </div>
      
      <div className="bg-neutral-100 rounded-lg p-4">
        <h2 className="text-lg font-medium text-neutral-800 mb-3">Reporting Guidelines</h2>
        <ul className="space-y-2 text-neutral-700">
          <li className="flex items-start">
            <div className="h-5 w-5 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center text-xs font-bold mr-2 mt-0.5">
              1
            </div>
            <span>Only report when you are physically at the bus stop or on the bus</span>
          </li>
          <li className="flex items-start">
            <div className="h-5 w-5 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center text-xs font-bold mr-2 mt-0.5">
              2
            </div>
            <span>Be accurate about the crowd level to help fellow commuters</span>
          </li>
          <li className="flex items-start">
            <div className="h-5 w-5 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center text-xs font-bold mr-2 mt-0.5">
              3
            </div>
            <span>Include any important information like delays or route changes</span>
          </li>
          <li className="flex items-start">
            <div className="h-5 w-5 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center text-xs font-bold mr-2 mt-0.5">
              4
            </div>
            <span>Accurate reports help you earn reputation points!</span>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default ReportPage;