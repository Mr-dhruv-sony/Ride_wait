import { create } from 'zustand';

export interface User {
  id: string;
  name: string;
  email: string;
  photoURL?: string;
  reputation: number;
  reportsCount: number;
}

interface AuthState {
  isAuthenticated: boolean;
  isLoading: boolean;
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  logout: () => void;
}

// This is a mock implementation that would be replaced with a real auth provider
export const useAuthStore = create<AuthState>((set) => ({
  isAuthenticated: localStorage.getItem('auth_user') !== null,
  isLoading: false,
  user: localStorage.getItem('auth_user') 
    ? JSON.parse(localStorage.getItem('auth_user') || '{}') 
    : null,
  
  login: async (email, password) => {
    set({ isLoading: true });
    
    try {
      // Mock API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Validation
      if (email === 'test@example.com' && password === 'password') {
        const user: User = {
          id: '1',
          name: 'Test User',
          email: 'test@example.com',
          reputation: 120,
          reportsCount: 25
        };
        
        localStorage.setItem('auth_user', JSON.stringify(user));
        set({ isAuthenticated: true, user, isLoading: false });
      } else {
        throw new Error('Invalid credentials');
      }
    } catch (error) {
      set({ isLoading: false });
      throw error;
    }
  },
  
  register: async (name, email, password) => {
    set({ isLoading: true });
    
    try {
      // Mock API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const user: User = {
        id: Date.now().toString(),
        name,
        email,
        reputation: 0,
        reportsCount: 0
      };
      
      localStorage.setItem('auth_user', JSON.stringify(user));
      set({ isAuthenticated: true, user, isLoading: false });
    } catch (error) {
      set({ isLoading: false });
      throw error;
    }
  },
  
  logout: () => {
    localStorage.removeItem('auth_user');
    set({ isAuthenticated: false, user: null });
  }
}));