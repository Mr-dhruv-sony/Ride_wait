import { create } from 'zustand';

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  timestamp: Date;
  isRead: boolean;
  type: 'alert' | 'info' | 'update';
  routeId?: string;
}

interface NotificationsState {
  notifications: Notification[];
  isLoading: boolean;
  unreadCount: number;
  fetchNotifications: () => Promise<void>;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  deleteNotification: (id: string) => void;
}

export const useNotificationsStore = create<NotificationsState>((set, get) => ({
  notifications: [],
  isLoading: false,
  unreadCount: 0,
  
  fetchNotifications: async () => {
    set({ isLoading: true });
    
    try {
      // Mock API call
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Mock data
      const mockNotifications: Notification[] = [
        {
          id: '1',
          userId: '1',
          title: 'Route 401 Delay',
          message: 'Route 401 is experiencing a 15-minute delay due to heavy traffic near Tech Park.',
          timestamp: new Date(Date.now() - 30 * 60000), // 30 minutes ago
          isRead: false,
          type: 'alert',
          routeId: '1'
        },
        {
          id: '2',
          userId: '1',
          title: 'Your Report was Helpful',
          message: 'Your recent report on Route 225 was confirmed by 5 other users. You earned 10 reputation points!',
          timestamp: new Date(Date.now() - 2 * 60 * 60000), // 2 hours ago
          isRead: false,
          type: 'info'
        },
        {
          id: '3',
          userId: '1',
          title: 'New Route Added',
          message: 'A new route 550 has been added connecting Central Station to the Western Suburbs.',
          timestamp: new Date(Date.now() - 1 * 24 * 60 * 60000), // 1 day ago
          isRead: true,
          type: 'update'
        },
        {
          id: '4',
          userId: '1',
          title: 'Weekend Schedule Change',
          message: 'Route 103 will operate on a reduced frequency during the upcoming weekend due to road maintenance.',
          timestamp: new Date(Date.now() - 2 * 24 * 60 * 60000), // 2 days ago
          isRead: true,
          type: 'alert',
          routeId: '5'
        }
      ];
      
      set({ 
        notifications: mockNotifications, 
        isLoading: false,
        unreadCount: mockNotifications.filter(n => !n.isRead).length
      });
    } catch (error) {
      set({ isLoading: false });
      console.error('Error fetching notifications:', error);
    }
  },
  
  markAsRead: (id: string) => {
    const { notifications } = get();
    const updatedNotifications = notifications.map(notification => 
      notification.id === id ? { ...notification, isRead: true } : notification
    );
    
    set({ 
      notifications: updatedNotifications,
      unreadCount: updatedNotifications.filter(n => !n.isRead).length
    });
  },
  
  markAllAsRead: () => {
    const { notifications } = get();
    const updatedNotifications = notifications.map(notification => ({ ...notification, isRead: true }));
    
    set({ 
      notifications: updatedNotifications,
      unreadCount: 0
    });
  },
  
  deleteNotification: (id: string) => {
    const { notifications } = get();
    const updatedNotifications = notifications.filter(notification => notification.id !== id);
    
    set({ 
      notifications: updatedNotifications,
      unreadCount: updatedNotifications.filter(n => !n.isRead).length
    });
  }
}));