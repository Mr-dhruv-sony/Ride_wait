import { create } from 'zustand';
import { format } from 'date-fns';

export interface BusRoute {
  id: string;
  number: string;
  name: string;
  source: string;
  destination: string;
  stops: string[];
  operatingHours: string;
  frequency: string;
  isFavorite: boolean;
}

export interface BusReport {
  id: string;
  routeId: string;
  userId: string;
  userName: string;
  userReputation: number;
  location: {
    lat: number;
    lng: number;
    locationName: string;
  };
  timestamp: Date;
  crowdLevel: 'empty' | 'moderate' | 'crowded' | 'full';
  message?: string;
}

interface RoutesState {
  routes: BusRoute[];
  reports: BusReport[];
  searchTerm: string;
  isLoading: boolean;
  favoriteRoutes: string[];
  fetchRoutes: () => Promise<void>;
  fetchReports: (routeId: string) => Promise<BusReport[]>;
  toggleFavorite: (routeId: string) => void;
  searchRoutes: (term: string) => void;
  addReport: (report: Omit<BusReport, 'id' | 'timestamp'>) => Promise<void>;
}

export const useRoutesStore = create<RoutesState>((set, get) => ({
  routes: [],
  reports: [],
  searchTerm: '',
  isLoading: false,
  favoriteRoutes: JSON.parse(localStorage.getItem('favorite_routes') || '[]'),
  
  fetchRoutes: async () => {
    set({ isLoading: true });
    
    try {
      // Mock API call
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Mock data
      const mockRoutes: BusRoute[] = [
        {
          id: '1',
          number: '401',
          name: 'Central Station - Tech Park Express',
          source: 'Central Bus Station',
          destination: 'Tech Park',
          stops: ['Central Bus Station', 'City Market', 'University Campus', 'Hospital', 'Tech Park'],
          operatingHours: '6:00 AM - 10:00 PM',
          frequency: 'Every 15 minutes',
          isFavorite: get().favoriteRoutes.includes('1')
        },
        {
          id: '2',
          number: '225',
          name: 'Airport - Downtown',
          source: 'International Airport',
          destination: 'Downtown',
          stops: ['International Airport', 'Silk Board', 'HSR Layout', 'Koramangala', 'MG Road', 'Downtown'],
          operatingHours: '4:30 AM - 11:30 PM',
          frequency: 'Every 20 minutes',
          isFavorite: get().favoriteRoutes.includes('2')
        },
        {
          id: '3',
          number: '500',
          name: 'North Campus - South Campus',
          source: 'North Campus',
          destination: 'South Campus',
          stops: ['North Campus', 'Library', 'Sports Complex', 'Science Building', 'Engineering Block', 'South Campus'],
          operatingHours: '7:00 AM - 9:00 PM',
          frequency: 'Every 30 minutes',
          isFavorite: get().favoriteRoutes.includes('3')
        },
        {
          id: '4',
          number: '335',
          name: 'Residential Area - Market Circle',
          source: 'Residential Complex',
          destination: 'Market Circle',
          stops: ['Residential Complex', 'Park', 'School Zone', 'Shopping Mall', 'Cinema Hall', 'Market Circle'],
          operatingHours: '6:30 AM - 9:30 PM',
          frequency: 'Every 25 minutes',
          isFavorite: get().favoriteRoutes.includes('4')
        },
        {
          id: '5',
          number: '103',
          name: 'Hill View - Beach Road',
          source: 'Hill View',
          destination: 'Beach Road',
          stops: ['Hill View', 'Botanical Garden', 'Zoo', 'Museum', 'Light House', 'Beach Road'],
          operatingHours: '8:00 AM - 8:00 PM',
          frequency: 'Every 40 minutes',
          isFavorite: get().favoriteRoutes.includes('5')
        }
      ];
      
      set({ routes: mockRoutes, isLoading: false });
    } catch (error) {
      set({ isLoading: false });
      console.error('Error fetching routes:', error);
    }
  },
  
  fetchReports: async (routeId: string) => {
    set({ isLoading: true });
    
    try {
      // Mock API call
      await new Promise(resolve => setTimeout(resolve, 600));
      
      // Generate reports with timestamps within the last hour
      const now = new Date();
      
      // Mock data
      const mockReports: BusReport[] = [
        {
          id: '1',
          routeId,
          userId: 'user1',
          userName: 'Rahul S.',
          userReputation: 85,
          location: {
            lat: 12.9716,
            lng: 77.5946,
            locationName: 'City Market'
          },
          timestamp: new Date(now.getTime() - 15 * 60000), // 15 minutes ago
          crowdLevel: 'moderate',
          message: 'Bus is on time and moderately filled'
        },
        {
          id: '2',
          routeId,
          userId: 'user2',
          userName: 'Priya M.',
          userReputation: 120,
          location: {
            lat: 12.9767,
            lng: 77.5713,
            locationName: 'University Campus'
          },
          timestamp: new Date(now.getTime() - 8 * 60000), // 8 minutes ago
          crowdLevel: 'crowded',
          message: 'Bus is getting crowded now'
        },
        {
          id: '3',
          routeId,
          userId: 'user3',
          userName: 'Aditya K.',
          userReputation: 45,
          location: {
            lat: 12.9819,
            lng: 77.6062,
            locationName: 'Hospital'
          },
          timestamp: new Date(now.getTime() - 2 * 60000), // 2 minutes ago
          crowdLevel: 'full',
          message: 'Bus is completely full, might skip some stops'
        }
      ];
      
      set({ reports: mockReports, isLoading: false });
      return mockReports;
    } catch (error) {
      set({ isLoading: false });
      console.error('Error fetching reports:', error);
      return [];
    }
  },
  
  toggleFavorite: (routeId: string) => {
    const { routes, favoriteRoutes } = get();
    let newFavorites: string[];
    
    if (favoriteRoutes.includes(routeId)) {
      newFavorites = favoriteRoutes.filter(id => id !== routeId);
    } else {
      newFavorites = [...favoriteRoutes, routeId];
    }
    
    localStorage.setItem('favorite_routes', JSON.stringify(newFavorites));
    
    set({
      favoriteRoutes: newFavorites,
      routes: routes.map(route => 
        route.id === routeId 
          ? { ...route, isFavorite: !route.isFavorite } 
          : route
      )
    });
  },
  
  searchRoutes: (term: string) => {
    set({ searchTerm: term });
  },
  
  addReport: async (reportData) => {
    set({ isLoading: true });
    
    try {
      // Mock API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const newReport: BusReport = {
        id: Date.now().toString(),
        timestamp: new Date(),
        ...reportData
      };
      
      set(state => ({
        reports: [newReport, ...state.reports],
        isLoading: false
      }));
    } catch (error) {
      set({ isLoading: false });
      console.error('Error adding report:', error);
      throw error;
    }
  }
}));