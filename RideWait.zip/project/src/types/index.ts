export interface User {
  id: string;
  name: string;
  email: string;
  photoURL?: string;
  reputation: number;
  reportsCount: number;
}

export interface BusRoute {
  id: string;
  number: string;
  name: string;
  source: string;
  destination: string;
  stops: string[];
  operatingHours: string;
  frequency: string;
  isFavorite: boolean;
}

export interface BusReport {
  id: string;
  routeId: string;
  userId: string;
  userName: string;
  userReputation: number;
  location: {
    lat: number;
    lng: number;
    locationName: string;
  };
  timestamp: Date;
  crowdLevel: 'empty' | 'moderate' | 'crowded' | 'full';
  message?: string;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  timestamp: Date;
  isRead: boolean;
  type: 'alert' | 'info' | 'update';
  routeId?: string;
}